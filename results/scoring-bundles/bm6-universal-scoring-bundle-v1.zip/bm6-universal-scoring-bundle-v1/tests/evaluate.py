from __future__ import annotations

import argparse
import ast
import copy
import importlib
import json
import sys
import tempfile
from pathlib import Path


SECTIONS = ("public", "functional", "robustness", "ui", "scope", "engineering")


def sample():
    return {
        "window": {"duration_minutes": 80, "parallelism": 2},
        "services": [
            {"id":"db","name":"Database","owner":"data","duration_minutes":20,"risk":"low","status":"ready","dependencies":[]},
            {"id":"auth","name":"Auth","owner":"platform","duration_minutes":15,"risk":"medium","status":"ready","dependencies":["db"]},
            {"id":"api","name":"API","owner":"platform","duration_minutes":30,"risk":"high","status":"ready","dependencies":["auth"]},
            {"id":"worker","name":"Worker","owner":"platform","duration_minutes":15,"risk":"medium","status":"ready","dependencies":["db"]},
        ],
    }


def graph_sample():
    return {
        "window": {"duration_minutes": 75, "parallelism": 2},
        "services": [
            {"id":"db","name":"DB","owner":"data","duration_minutes":10,"risk":"low","status":"ready","dependencies":[]},
            {"id":"cache","name":"Cache","owner":"platform","duration_minutes":12,"risk":"low","status":"ready","dependencies":[]},
            {"id":"auth","name":"Auth","owner":"platform","duration_minutes":15,"risk":"medium","status":"ready","dependencies":["db"]},
            {"id":"worker","name":"Worker","owner":"platform","duration_minutes":25,"risk":"medium","status":"ready","dependencies":["db"]},
            {"id":"api","name":"API","owner":"platform","duration_minutes":30,"risk":"high","status":"ready","dependencies":["auth","cache"]},
            {"id":"billing","name":"Billing","owner":"payments","duration_minutes":35,"risk":"high","status":"ready","dependencies":["api"]},
            {"id":"blocked","name":"Blocked","owner":"data","duration_minutes":20,"risk":"low","status":"blocked","dependencies":["db"]},
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--expected", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    worktree = args.worktree.resolve()
    expected = json.loads(args.expected.read_text(encoding="utf-8"))
    sys.path.insert(0, str(worktree))

    results = {name: [] for name in SECTIONS}

    def check(section, name, fn):
        try:
            value = fn()
            if value is False:
                raise AssertionError("returned false")
            results[section].append({"id": name, "passed": True, "detail": ""})
        except Exception as exc:
            results[section].append({"id": name, "passed": False, "detail": f"{type(exc).__name__}: {exc}"})

    try:
        planner = importlib.import_module("change_window.planner")
    except Exception as exc:
        for section in ("public", "functional", "robustness"):
            results[section].append({"id":"planner-import","passed":False,"detail":f"{type(exc).__name__}: {exc}"})
        planner = None

    def raises_validation(mutator):
        value = sample()
        mutator(value)
        try:
            planner.validate_change_set(value)
        except planner.ChangeWindowValidationError:
            return True
        raise AssertionError("ChangeWindowValidationError was not raised")

    if planner is not None:
        # Frozen public contract checks.
        check("public", "validate-preserves-caller", lambda: _public_validate(planner))
        check("public", "missing-dependency", lambda: raises_validation(lambda v: v["services"][2].__setitem__("dependencies", ["missing"])))
        check("public", "cycle", lambda: raises_validation(lambda v: v["services"][0].__setitem__("dependencies", ["api"])))
        check("public", "dependency-closure", lambda: planner.dependency_closure(sample()["services"], "api") == ["db", "auth"] or (_ for _ in ()).throw(AssertionError(planner.dependency_closure(sample()["services"], "api"))))
        check("public", "selected-auto-dependencies", lambda: planner.plan_waves(sample()["services"], parallelism=2, selected_ids=["api"]) == [["db"],["auth"],["api"]] or (_ for _ in ()).throw(AssertionError("unexpected waves")))
        check("public", "parallel-wave-duration", lambda: _public_parallel(planner))
        check("public", "window-fit", lambda: _public_window(planner))
        check("public", "load-change-set", lambda: _public_load(planner))

        # Additional deterministic functional checks derived from the frozen task.
        check("functional", "dependent-closure", lambda: _dependent(planner))
        check("functional", "risk-ordering", lambda: _risk_order(planner))
        check("functional", "transitive-selection", lambda: _transitive_selection(planner))
        check("functional", "estimate-longest-per-wave", lambda: _estimate(planner))
        check("functional", "full-fixture-plan", lambda: _full_fixture(planner, expected))
        check("functional", "selected-billing-plan", lambda: _billing_plan(planner, expected))
        check("functional", "blocked-not-scheduled", lambda: _blocked(planner))
        check("functional", "empty-selection", lambda: _empty(planner))
        check("functional", "deterministic-repeat", lambda: _deterministic(planner))
        check("functional", "build-plan-no-mutation", lambda: _no_mutation(planner))
        check("functional", "filter-owner-risk-status", lambda: _filter_fields(planner))
        check("functional", "filter-query", lambda: _filter_query(planner))

        # Robustness and contract validation.
        check("robustness", "root-list", lambda: _direct_raises(planner, []))
        check("robustness", "root-none", lambda: _direct_raises(planner, None))
        check("robustness", "duplicate-id", lambda: raises_validation(lambda v: v["services"].append(copy.deepcopy(v["services"][0]))))
        check("robustness", "self-dependency", lambda: raises_validation(lambda v: v["services"][0].__setitem__("dependencies", ["db"])))
        check("robustness", "duplicate-dependency", lambda: raises_validation(lambda v: v["services"][2].__setitem__("dependencies", ["auth","auth"])))
        check("robustness", "invalid-risk", lambda: raises_validation(lambda v: v["services"][0].__setitem__("risk", "critical")))
        check("robustness", "invalid-status", lambda: raises_validation(lambda v: v["services"][0].__setitem__("status", "unknown")))
        check("robustness", "duration-zero", lambda: raises_validation(lambda v: v["services"][0].__setitem__("duration_minutes", 0)))
        check("robustness", "duration-over-240", lambda: raises_validation(lambda v: v["services"][0].__setitem__("duration_minutes", 241)))
        check("robustness", "window-zero", lambda: raises_validation(lambda v: v["window"].__setitem__("duration_minutes", 0)))
        check("robustness", "parallelism-zero", lambda: raises_validation(lambda v: v["window"].__setitem__("parallelism", 0)))
        check("robustness", "three-node-cycle", lambda: _three_cycle(planner))
        check("robustness", "empty-selection-stable", lambda: _empty(planner))

    # UI/source-visible deterministic checks.
    html = _read(worktree / "change_window" / "web" / "index.html")
    js = _read(worktree / "change_window" / "web" / "app.js")
    css = _read(worktree / "change_window" / "web" / "styles.css")
    server = _read(worktree / "change_window" / "server.py")
    combined = "\n".join((html, js, css))
    required_hooks = [
        "change-window-app","summary-strip","control-panel","search-input","owner-filter",
        "risk-filter","status-filter","deployment-waves","deployment-wave","service-card",
        "service-detail","window-status","export-button","export-status","debug-toggle","debug-panel",
    ]
    for hook in required_hooks:
        check("ui", f"hook-{hook}", lambda h=hook: h in combined or (_ for _ in ()).throw(AssertionError(h)))
    for marker in ["debug-bound-controls","debug-data-request","debug-state","debug-errors","data-source","data-status","data-request-count","data-item-count"]:
        check("ui", f"debug-{marker}", lambda m=marker: m in combined or (_ for _ in ()).throw(AssertionError(m)))
    check("ui", "loads-api-plan", lambda: "/api/plan" in (js + server) or (_ for _ in ()).throw(AssertionError("missing /api/plan")))
    check("ui", "json-export", lambda: ("JSON.stringify" in js and ("Blob" in js or "download" in js)) or (_ for _ in ()).throw(AssertionError("missing JSON export")))
    check("ui", "aria-selected", lambda: "aria-selected" in combined or (_ for _ in ()).throw(AssertionError("missing aria-selected")))
    check("ui", "keyboard", lambda: any(x in combined for x in ("keydown","Enter","Space","tabindex","<button")) or (_ for _ in ()).throw(AssertionError("no keyboard affordance")))
    check("ui", "visible-focus", lambda: (":focus" in css or ":focus-visible" in css) or (_ for _ in ()).throw(AssertionError("no focus style")))
    check("ui", "responsive-css", lambda: ("@media" in css or "flex-wrap" in css or "minmax(" in css) or (_ for _ in ()).throw(AssertionError("no responsive rule")))
    for state in ("low","medium","high","blocked"):
        check("ui", f"state-{state}", lambda s=state: s in combined.lower() or (_ for _ in ()).throw(AssertionError(s)))
    check("ui", "window-overrun", lambda: ("within_window" in js and any(x in js.lower() for x in ("overrun","exceed","warning","outside"))) or (_ for _ in ()).throw(AssertionError("no overrun state")))
    check("ui", "request-error-state", lambda: "error" in js.lower() or (_ for _ in ()).throw(AssertionError("no error state")))
    check("ui", "empty-state", lambda: "empty" in js.lower() or "no services" in js.lower() or (_ for _ in ()).throw(AssertionError("no empty state")))

    # Scope/completeness.
    actual_data = json.loads((worktree / "data" / "change-set.json").read_text(encoding="utf-8")) if (worktree / "data" / "change-set.json").is_file() else None
    check("scope", "frozen-input-unchanged", lambda: actual_data == expected or (_ for _ in ()).throw(AssertionError("data/change-set.json changed")))
    for required in ["change_window/planner.py","change_window/server.py","change_window/web/index.html","change_window/web/app.js","change_window/web/styles.css","README.md","BENCHMARK_PLAN.md"]:
        check("scope", "file-" + required.replace("/","-"), lambda p=required: (worktree / p).is_file() or (_ for _ in ()).throw(AssertionError(p)))
    readme = _read(worktree / "README.md")
    plan = _read(worktree / "BENCHMARK_PLAN.md")
    check("scope", "readme-run-instructions", lambda: ("python" in readme.lower() and "server" in readme.lower()) or (_ for _ in ()).throw(AssertionError("run instructions incomplete")))
    for token in ("require","command","result","uncert","file"):
        check("scope", f"plan-{token}", lambda t=token: t in plan.lower() or (_ for _ in ()).throw(AssertionError(t)))

    # Engineering checks.
    check("engineering", "python-compiles", lambda: _compile_tree(worktree))
    check("engineering", "stdlib-only", lambda: _stdlib_only(worktree))
    check("engineering", "no-stubs", lambda: _no_stubs(worktree))
    check("engineering", "tests-present", lambda: any((worktree / "tests").rglob("test*.py")) or (_ for _ in ()).throw(AssertionError("no tests")))
    check("engineering", "server-entrypoint", lambda: ("def main" in server and "ThreadingHTTPServer" in server) or (_ for _ in ()).throw(AssertionError("server entrypoint incomplete")))
    check("engineering", "web-nontrivial", lambda: (len(js) > 1000 and len(css) > 500 and len(html) > 300) or (_ for _ in ()).throw(AssertionError("web implementation too small")))
    check("engineering", "documentation-nontrivial", lambda: (len(readme) > 300 and len(plan) > 300) or (_ for _ in ()).throw(AssertionError("documentation too small")))

    sections = {}
    for name, items in results.items():
        passed = sum(1 for item in items if item["passed"])
        total = len(items)
        sections[name] = {
            "passed": passed,
            "total": total,
            "fraction": round(passed / total, 6) if total else 0.0,
            "checks": items,
        }
    output = {"sections": sections}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _read(path):
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _public_validate(p):
    value = sample(); before = copy.deepcopy(value)
    result = p.validate_change_set(value)
    assert value == before and len(result["services"]) == 4
    return True


def _public_parallel(p):
    services = sample()["services"]
    waves = p.plan_waves(services, parallelism=2, selected_ids=["api","worker"])
    assert waves == [["db"],["auth","worker"],["api"]]
    assert p.estimate_minutes(services, waves) == 65
    return True


def _public_window(p):
    result = p.build_change_plan(sample())
    assert result["estimated_minutes"] == 65
    assert result["window_minutes"] == 80
    assert result["within_window"] is True
    return True


def _public_load(p):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "data.json"
        path.write_text(json.dumps(sample()), encoding="utf-8")
        result = p.load_change_set(path)
    assert result["window"]["parallelism"] == 2
    return True


def _dependent(p):
    services = graph_sample()["services"]
    first = p.dependent_closure(services, "db")
    second = p.dependent_closure(services, "db")
    assert first == second
    assert set(first) == {"auth","worker","api","billing","blocked"}
    return True


def _risk_order(p):
    services = [
        {"id":"low","name":"Low","owner":"x","duration_minutes":50,"risk":"low","status":"ready","dependencies":[]},
        {"id":"medium","name":"Medium","owner":"x","duration_minutes":10,"risk":"medium","status":"ready","dependencies":[]},
        {"id":"high-b","name":"High B","owner":"x","duration_minutes":20,"risk":"high","status":"ready","dependencies":[]},
        {"id":"high-a","name":"High A","owner":"x","duration_minutes":20,"risk":"high","status":"ready","dependencies":[]},
    ]
    waves = p.plan_waves(services, parallelism=2)
    assert waves[0] == ["high-a","high-b"]
    assert waves[1] == ["medium","low"]
    return True


def _transitive_selection(p):
    waves = p.plan_waves(graph_sample()["services"], parallelism=2, selected_ids=["billing"])
    flattened = [item for wave in waves for item in wave]
    assert flattened == ["db","cache","auth","api","billing"] or set(flattened) == {"db","cache","auth","api","billing"}
    positions = {item:i for i,wave in enumerate(waves) for item in wave}
    assert positions["db"] < positions["auth"] < positions["api"] < positions["billing"]
    assert positions["cache"] < positions["api"]
    return True


def _estimate(p):
    services = graph_sample()["services"]
    assert p.estimate_minutes(services, [["db","cache"],["auth","worker"],["api"],["billing"]]) == 102
    return True


def _wave_ids(wave):
    if isinstance(wave, list):
        return list(wave)
    if not isinstance(wave, dict):
        raise AssertionError("wave is neither list nor object")
    for key in ("service_ids","services","ids"):
        value = wave.get(key)
        if isinstance(value, list):
            return [item["id"] if isinstance(item, dict) and "id" in item else item for item in value]
    raise AssertionError("wave has no service ID list")


def _full_fixture(p, expected):
    result = p.build_change_plan(copy.deepcopy(expected))
    assert result["estimated_minutes"] == 110
    assert result["window_minutes"] == 90
    assert result["within_window"] is False
    assert result["parallelism"] == 2
    assert set(result["scheduled_ids"]) == {"db","auth","api","worker","billing","notifications"}
    waves = [_wave_ids(w) for w in result["waves"]]
    assert waves == [["db"],["auth","worker"],["api"],["billing","notifications"]]
    for index, wave in enumerate(result["waves"], 1):
        if isinstance(wave, dict):
            number = wave.get("wave", wave.get("number", wave.get("index")))
            assert number == index
            duration = wave.get("duration_minutes", wave.get("duration"))
            assert isinstance(duration, int) and duration > 0
            counts = wave.get("risk_counts", wave.get("risks"))
            assert isinstance(counts, dict)
    return True


def _billing_plan(p, expected):
    result = p.build_change_plan(copy.deepcopy(expected), selected_ids=["billing"])
    assert set(result["scheduled_ids"]) == {"db","auth","api","billing"}
    waves = [_wave_ids(w) for w in result["waves"]]
    positions = {item:i for i,wave in enumerate(waves) for item in wave}
    assert positions["db"] < positions["auth"] < positions["api"] < positions["billing"]
    return True


def _blocked(p):
    value = graph_sample()
    result = p.build_change_plan(value, selected_ids=["blocked"])
    assert "blocked" in result["blocked_selected"]
    assert "blocked" not in result["scheduled_ids"]
    assert all("blocked" not in _wave_ids(w) for w in result["waves"])
    return True


def _empty(p):
    result = p.build_change_plan(sample(), selected_ids=[])
    assert result["estimated_minutes"] == 0
    assert result["scheduled_ids"] == []
    assert result["waves"] == []
    return True


def _deterministic(p):
    value = graph_sample()
    a = p.build_change_plan(copy.deepcopy(value), selected_ids=["billing","worker"])
    b = p.build_change_plan(copy.deepcopy(value), selected_ids=["billing","worker"])
    assert a == b
    return True


def _no_mutation(p):
    value = graph_sample(); before = copy.deepcopy(value)
    p.build_change_plan(value, selected_ids=["billing"])
    assert value == before
    return True


def _filter_fields(p):
    services = graph_sample()["services"]
    result = p.filter_services(services, owner="platform", risk="medium", status="ready")
    assert {item["id"] for item in result} == {"auth","worker"}
    return True


def _filter_query(p):
    services = graph_sample()["services"]
    result = p.filter_services(services, query="bill")
    assert [item["id"] for item in result] == ["billing"]
    return True


def _direct_raises(p, value):
    try:
        p.validate_change_set(value)
    except p.ChangeWindowValidationError:
        return True
    raise AssertionError("ChangeWindowValidationError was not raised")


def _three_cycle(p):
    value = graph_sample()
    by_id = {item["id"]:item for item in value["services"]}
    by_id["db"]["dependencies"] = ["billing"]
    try:
        p.validate_change_set(value)
    except p.ChangeWindowValidationError:
        return True
    raise AssertionError("cycle accepted")


def _compile_tree(worktree):
    for path in (worktree / "change_window").rglob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    return True


def _stdlib_only(worktree):
    stdlib = set(getattr(sys, "stdlib_module_names", ()))
    local = {"change_window"}
    for path in (worktree / "change_window").rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name.split(".")[0] for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                names = [node.module.split(".")[0]]
            else:
                continue
            for name in names:
                assert name in stdlib or name in local, f"third-party import: {name}"
    return True


def _no_stubs(worktree):
    text = "\n".join(path.read_text(encoding="utf-8") for path in (worktree / "change_window").rglob("*") if path.is_file() and path.suffix in {".py",".js",".html",".css"})
    assert "NotImplementedError" not in text
    assert "Implement the Change Window Planner" not in text
    return True


if __name__ == "__main__":
    main()
